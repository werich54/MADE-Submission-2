package com.example.moviee;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FilmAdapter extends RecyclerView.Adapter<FilmAdapter.MyViewHolder> {
    private ArrayList<Film> mKatalogFilm;
    private OnItemClickListener mListener;

    public FilmAdapter() {

    }

    public interface  OnItemClickListener{
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageView mImageView;
        public TextView mTextview1;


        public MyViewHolder(View itemView, final OnItemClickListener listener){
            super(itemView);
            mImageView = itemView.findViewById(R.id.imageTv);
            mTextview1 = itemView.findViewById(R.id.titleTv);

            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    if (listener != null ) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }

    public FilmAdapter(ArrayList<Film> mkatalogFilm){
        mKatalogFilm = mkatalogFilm;
    }
    @Override
    public MyViewHolder onCreateViewHolder (ViewGroup parent, int viewtype){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_film, parent, false);
        MyViewHolder evh = new MyViewHolder(v, mListener);
        return evh;
    }
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position){
        Film currentItem = mKatalogFilm.get(position);

        holder.mImageView.setImageResource(currentItem.getImageResource());
        holder.mTextview1.setText(currentItem.getText1());
    }

    @Override
    public int getItemCount(){
        return mKatalogFilm.size();
    }
}
