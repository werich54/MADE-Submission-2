package com.example.moviee;

public class TvData {
    public static String[] kartun = new String[]{

            "Naruto",
            "Captain Tsubasa",
            "Spongebob",
            "Doraemon",
            "Hamtaro",
            "Arnold",
            "Jimy Neutron",
            "One Piece",
            "Shinchan",
            "Shaun The Sheep"


    };

    public static int[] gambar = new int[]{

            R.drawable.naruto,
            R.drawable.tsubasa,
            R.drawable.spons,
            R.drawable.doraemon,
            R.drawable.hamtaro,
            R.drawable.arnold,
            R.drawable.jimy,
            R.drawable.one,
            R.drawable.sincan,
            R.drawable.shaun

    };

}
