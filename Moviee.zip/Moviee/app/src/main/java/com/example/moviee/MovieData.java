package com.example.moviee;

import java.util.ArrayList;

public class MovieData {

    public static String[] title = new String[]{
            "A star Born",
            "Aquaman",
            "Avengers",
            "BirdBox",
            "Bohemian",
            "BumbleBee",
            "Creed II",
            "Deadpool",
            "Dragon",
            "Dragonball"
    };

    public static int[] foto = new int[]{
            R.drawable.poster_a_star,
            R.drawable.poster_aquaman,
            R.drawable.poster_avengerinfinity,
            R.drawable.poster_birdbox,
            R.drawable.poster_bohemian,
            R.drawable.poster_bumblebee,
            R.drawable.poster_creed,
            R.drawable.poster_deadpool,
            R.drawable.poster_dragon,
            R.drawable.poster_dragonball
    };

}
