package com.example.moviee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MovieDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);

        Intent intent = getIntent();
        Film filmItem = getIntent().getExtras().getParcelable("parcel");


        int imageRes = filmItem.getImageResource();
        String teks1 = filmItem.getText1();
        String teks2 = filmItem.getText2();

        ImageView imageView = findViewById(R.id.imageView1);
        imageView.setImageResource(imageRes);

        TextView textView1 = findViewById(R.id.title1);
        textView1.setText(teks1);

        TextView textView2 = findViewById(R.id.description1);
        textView2.setText(teks2);
    }
}
