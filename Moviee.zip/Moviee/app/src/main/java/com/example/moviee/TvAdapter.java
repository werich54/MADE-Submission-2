package com.example.moviee;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TvAdapter extends RecyclerView.Adapter{
    public TvAdapter(ArrayList<Film> mKatalogFilm) {
    }

    public TvAdapter() {

    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tv, parent, false);
        return new FilmHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((FilmHolder) holder).bindView(position);
    }

    @Override
    public int getItemCount() {
        return TvData.kartun.length;
    }

    private class FilmHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView text1;
        private ImageView imgPoster;

        public FilmHolder(View itemView){

            super(itemView);
            text1 = (TextView) itemView.findViewById(R.id.titleTv2);
            imgPoster = (ImageView) itemView.findViewById(R.id.imageTv2);
            itemView.setOnClickListener(this);
        }

        public void bindView(int position){
            text1.setText(TvData.kartun[position]);
            imgPoster.setImageResource(TvData.gambar[position]);
        }

        public void onClick(View view){

        }
    }
}
